import React, { useState, useEffect } from 'react';
import { GlobalSettings, TabId } from './types';
import { DEFAULT_SETTINGS, TABS } from './constants';
import { ApiSettingsPanel } from './components/ApiSettingsPanel';
import { TabPanel } from './components/TabPanel';
import { Settings, X } from 'lucide-react';

function App() {
  const [settings, setSettings] = useState<GlobalSettings>(DEFAULT_SETTINGS);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<TabId>('func1');
  const [zoomImage, setZoomImage] = useState<string | null>(null);

  // Load settings from LocalStorage on mount
  useEffect(() => {
    const storedProvider = localStorage.getItem('apiProvider');
    
    const loadSettingsFor = (p: 'openai' | 'google') => ({
        visionApiUrl: localStorage.getItem(`${p}_visionApiUrl`) || DEFAULT_SETTINGS[p].visionApiUrl,
        visionModel: localStorage.getItem(`${p}_visionModel`) || DEFAULT_SETTINGS[p].visionModel,
        visionApiKey: localStorage.getItem(`${p}_visionApiKey`) || '',
        textApiUrl: localStorage.getItem(`${p}_textApiUrl`) || DEFAULT_SETTINGS[p].textApiUrl,
        textModel: localStorage.getItem(`${p}_textModel`) || DEFAULT_SETTINGS[p].textModel,
        textApiKey: localStorage.getItem(`${p}_textApiKey`) || '',
    });

    setSettings({
        provider: (storedProvider as any) || 'openai',
        openai: loadSettingsFor('openai'),
        google: loadSettingsFor('google')
    });
  }, []);

  const handleUpdateSettings = (newSettings: GlobalSettings) => {
    setSettings(newSettings);
    // Persist to local storage
    localStorage.setItem('apiProvider', newSettings.provider);
    
    const save = (p: 'openai' | 'google') => {
        const conf = newSettings[p];
        localStorage.setItem(`${p}_visionApiUrl`, conf.visionApiUrl);
        localStorage.setItem(`${p}_visionModel`, conf.visionModel);
        localStorage.setItem(`${p}_visionApiKey`, conf.visionApiKey);
        localStorage.setItem(`${p}_textApiUrl`, conf.textApiUrl);
        localStorage.setItem(`${p}_textModel`, conf.textModel);
        localStorage.setItem(`${p}_textApiKey`, conf.textApiKey);
    };
    save('openai');
    save('google');
  };

  return (
    <div className="min-h-screen pb-12">
      {/* Header */}
      <header className="bg-header-gradient text-white py-8 relative overflow-hidden shadow-lg">
         <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.1)_0%,transparent_60%)] pointer-events-none"></div>
         <div className="container mx-auto px-4 text-center relative z-10">
            <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight drop-shadow-sm">Smart 病历助手</h1>
            <p className="mt-2 text-blue-100 text-sm font-medium opacity-90">基于 AI 的高效医疗文书生成工具</p>
         </div>
      </header>

      {/* Sticky Settings Button */}
      <button 
        onClick={() => setIsSettingsOpen(!isSettingsOpen)}
        className={`
            fixed left-0 top-1/2 -translate-y-1/2 z-50 w-12 h-16 flex items-center justify-center 
            bg-primary text-white rounded-r-xl shadow-[4px_0_15px_rgba(59,130,246,0.4)]
            hover:w-14 hover:bg-primary-hover transition-all duration-300
        `}
        title="API 设置"
      >
        <Settings className="w-6 h-6 drop-shadow-md" />
      </button>

      {/* Settings Panel */}
      <ApiSettingsPanel 
        isOpen={isSettingsOpen} 
        settings={settings} 
        onUpdateSettings={handleUpdateSettings} 
        onClose={() => setIsSettingsOpen(false)} 
      />

      {/* Main Container */}
      <main className="container mx-auto max-w-5xl px-4 mt-8 md:-mt-6 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl border border-white/50 overflow-hidden min-h-[600px]">
            
            {/* Tabs Navigation */}
            <div className="flex overflow-x-auto border-b border-gray-100 bg-white px-4 gap-1 scrollbar-none">
                {TABS.map((tab) => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`
                            py-4 px-5 whitespace-nowrap font-medium text-sm md:text-base transition-all border-b-2 rounded-t-lg
                            ${activeTab === tab.id 
                                ? 'text-primary border-primary bg-primary-light/30' 
                                : 'text-gray-500 border-transparent hover:text-primary hover:bg-gray-50'
                            }
                        `}
                    >
                        {tab.title}
                    </button>
                ))}
            </div>

            {/* Tab Contents */}
            <div className="p-6 md:p-8">
                {TABS.map((tab) => (
                    <TabPanel 
                        key={tab.id}
                        tab={tab}
                        isActive={activeTab === tab.id}
                        settings={settings}
                        onZoomImage={setZoomImage}
                    />
                ))}
            </div>
        </div>
      </main>

      {/* Image Lightbox Modal */}
      {zoomImage && (
        <div 
            className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
            onClick={() => setZoomImage(null)}
        >
            <div className="relative max-w-[90vw] max-h-[90vh]">
                <button 
                    onClick={() => setZoomImage(null)}
                    className="absolute -top-12 right-0 text-white hover:text-danger transition-transform hover:scale-110 hover:rotate-90 duration-200"
                >
                    <X size={32} />
                </button>
                <img 
                    src={zoomImage} 
                    alt="Zoomed" 
                    className="max-w-full max-h-[90vh] rounded-lg shadow-2xl object-contain" 
                    onClick={(e) => e.stopPropagation()}
                />
            </div>
        </div>
      )}

      <footer className="text-center mt-12 text-gray-500 text-sm pb-8">
         <a href="https://www.bilibili.com/opus/1125289179704459280" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline font-semibold">使用说明</a>
         <span className="mx-2">•</span>
         Make by B站 Dr_薯条加点盐
      </footer>
    </div>
  );
}

export default App;