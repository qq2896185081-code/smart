export type ApiProvider = 'openai' | 'google';

export interface ApiSettings {
  visionApiUrl: string;
  visionModel: string;
  visionApiKey: string;
  textApiUrl: string;
  textModel: string;
  textApiKey: string;
}

export interface GlobalSettings {
  provider: ApiProvider;
  openai: ApiSettings;
  google: ApiSettings;
}

export interface ImageFile {
  file: File;
  previewUrl: string;
  base64?: string; // For API calls
  mimeType?: string;
}

export type TabId = 'func1' | 'func2' | 'func3' | 'func4' | 'func5';

export interface TabDefinition {
  id: TabId;
  title: string;
  header: string;
  imageLabel1: string;
  imageLabel2: string;
  textPlaceholder: string;
}