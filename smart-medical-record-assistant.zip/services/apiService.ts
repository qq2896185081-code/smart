import { ImageFile, GlobalSettings, ApiProvider } from '../types';

export async function compressImage(file: File, maxSizeMB = 15): Promise<{ base64: string; mimeType: string }> {
  const MAX_SIZE_BYTES = maxSizeMB * 1024 * 1024;
  const maxWidth = 1920;

  return new Promise((resolve, reject) => {
    // Use FileReader directly if small enough
    if (file.size < MAX_SIZE_BYTES) {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve({ base64: reader.result as string, mimeType: file.type });
      reader.onerror = error => reject(error);
      return;
    }

    // Compress using Canvas if too large
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
            reject(new Error("Could not get canvas context"));
            return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.8);
        resolve({ base64: compressedBase64, mimeType: 'image/jpeg' });
      };
      img.onerror = (error) => reject(error);
    };
    reader.onerror = (error) => reject(error);
  });
}

function getProviderSettings(settings: GlobalSettings, type: 'vision' | 'text') {
    const provider = settings.provider;
    const config = settings[provider];
    
    return {
        provider,
        url: type === 'vision' ? config.visionApiUrl : config.textApiUrl,
        model: type === 'vision' ? config.visionModel : config.textModel,
        key: type === 'vision' ? config.visionApiKey : config.textApiKey
    };
}

export async function callVisionAPI(
    prompt: string, 
    imageFiles: ImageFile[], 
    settings: GlobalSettings, 
    signal?: AbortSignal
): Promise<string> {
    const { provider, url, model, key } = getProviderSettings(settings, 'vision');

    // Special handling for Google API URL construction if empty
    let effectiveUrl = url;
    if (provider === 'google' && !effectiveUrl) {
        if (!key || !model) throw new Error("Google API Key or Model missing");
        effectiveUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;
    }

    if (!effectiveUrl) throw new Error("API URL not configured");
    if (provider !== 'google' && !key) throw new Error("API Key missing");

    // Compress images first
    const processedImages = await Promise.all(imageFiles.map(img => compressImage(img.file, 12)));

    let headers: Record<string, string> = { 'Content-Type': 'application/json' };
    let body: any;

    if (provider === 'google') {
        const imageParts = processedImages.map(img => ({
            inlineData: {
                mimeType: img.mimeType,
                data: img.base64.split(',')[1]
            }
        }));

        body = {
            contents: [{
                parts: [{ text: prompt }, ...imageParts]
            }],
            generationConfig: {
                temperature: 0.4,
                topP: 1,
                topK: 32,
                maxOutputTokens: 4096,
            }
        };
    } else {
        // OpenAI Compatible
        const imageContent = processedImages.map(img => ({
            type: 'image_url',
            image_url: { url: img.base64 }
        }));

        body = {
            model: model,
            messages: [{
                role: 'user',
                content: [{ type: 'text', text: prompt }, ...imageContent]
            }],
            temperature: 0.5,
            top_p: 0.8,
            max_tokens: 4096,
        };
        headers['Authorization'] = `Bearer ${key}`;
        
        if (effectiveUrl.includes('openrouter.ai')) {
            headers['HTTP-Referer'] = window.location.origin;
            headers['X-Title'] = 'Smart Medical Assistant';
        }
    }

    const response = await fetch(effectiveUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal
    });

    if (!response.ok) {
        const errorBody = await response.json().catch(() => response.text());
        const errorText = typeof errorBody === 'object' ? (errorBody.error?.message || JSON.stringify(errorBody)) : errorBody;
        throw new Error(`Vision API Error: ${response.status}. ${errorText}`);
    }

    const data = await response.json();

    if (provider === 'google') {
        if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
             throw new Error('Google API returned invalid response format.');
        }
        return data.candidates[0].content.parts[0].text;
    } else {
         if (!data.choices?.[0]?.message?.content) {
            if (data.error) throw new Error(`API Error: ${data.error.message}`);
            throw new Error('API returned invalid response format.');
        }
        return data.choices[0].message.content;
    }
}

export async function callTextAPI(
    prompt: string, 
    secondaryText: string, 
    settings: GlobalSettings, 
    signal?: AbortSignal
): Promise<string> {
    const { provider, url, model, key } = getProviderSettings(settings, 'text');

    let effectiveUrl = url;
    if (provider === 'google' && !effectiveUrl) {
        if (!key || !model) throw new Error("Google API Key or Model missing");
        effectiveUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;
    }

    if (!effectiveUrl) throw new Error("API URL not configured");
    if (provider !== 'google' && !key) throw new Error("API Key missing");

    let headers: Record<string, string> = { 'Content-Type': 'application/json' };
    let body: any;

    const fullContent = `${prompt}\n${secondaryText}`;

    if (provider === 'google') {
         body = {
            contents: [{
                parts: [{ text: fullContent }]
            }],
            generationConfig: {
                temperature: 0.4,
                topP: 1,
                topK: 32,
                maxOutputTokens: 8192,
            }
        };
    } else {
        body = {
            model: model,
            messages: [{ role: 'user', content: fullContent }],
            temperature: 0.5,
            top_p: 0.6,
            max_tokens: 8192,
        };
        headers['Authorization'] = `Bearer ${key}`;
    }

    const response = await fetch(effectiveUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal
    });

    if (!response.ok) {
        const errorBody = await response.json().catch(() => response.text());
        const errorText = typeof errorBody === 'object' ? (errorBody.error?.message || JSON.stringify(errorBody)) : errorBody;
        throw new Error(`Text API Error: ${response.status}. ${errorText}`);
    }
    const data = await response.json();

    if (provider === 'google') {
        if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
            throw new Error('Google API returned invalid response format.');
        }
        return data.candidates[0].content.parts[0].text;
    } else {
        if (!data.choices?.[0]?.message?.content) {
            if (data.error) throw new Error(`API Error: ${data.error.message}`);
            throw new Error('API returned invalid response format.');
        }
        return data.choices[0].message.content;
    }
}