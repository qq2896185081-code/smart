import React, { useRef } from 'react';
import { Upload, X, ZoomIn } from 'lucide-react';
import { ImageFile } from '../types';

interface Props {
  label: string;
  image: ImageFile | null;
  onChange: (file: File | null) => void;
  onZoom: (url: string) => void;
}

export const ImageUpload: React.FC<Props> = ({ label, image, onChange, onZoom }) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onChange(e.target.files[0]);
    }
  };

  return (
    <div className="relative w-full">
      <div 
        onClick={() => !image && inputRef.current?.click()}
        className={`
          group relative h-40 rounded-lg border-2 border-dashed transition-all duration-200 flex flex-col items-center justify-center cursor-pointer overflow-hidden
          ${image ? 'border-primary bg-blue-50' : 'border-gray-300 bg-gray-50 hover:border-primary hover:bg-blue-50'}
        `}
      >
        <input 
          type="file" 
          ref={inputRef}
          className="hidden" 
          accept="image/*"
          onChange={handleFileChange}
        />

        {image ? (
          <>
            <img src={image.previewUrl} alt="Preview" className="w-full h-full object-contain" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                <button 
                    onClick={(e) => { e.stopPropagation(); onZoom(image.previewUrl); }}
                    className="p-2 bg-white rounded-full text-gray-700 hover:text-primary transition-transform hover:scale-110"
                    title="放大查看"
                >
                    <ZoomIn size={20} />
                </button>
                <button 
                    onClick={(e) => { e.stopPropagation(); onChange(null); }}
                    className="p-2 bg-white rounded-full text-danger hover:text-danger-hover transition-transform hover:scale-110"
                    title="删除图片"
                >
                    <X size={20} />
                </button>
            </div>
            <div className="absolute bottom-0 left-0 right-0 bg-white/90 px-2 py-1 text-xs text-primary font-medium truncate text-center border-t border-primary/20">
                {image.file.name}
            </div>
          </>
        ) : (
          <div className="text-center p-4">
            <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400 group-hover:text-primary transition-colors" />
            <span className="text-sm text-gray-500 group-hover:text-primary font-medium">{label}</span>
          </div>
        )}
      </div>
    </div>
  );
};