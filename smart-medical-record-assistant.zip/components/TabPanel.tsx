import React, { useState, useRef, useEffect } from 'react';
import { TabDefinition, ImageFile, GlobalSettings } from '../types';
import { ImageUpload } from './ImageUpload';
import { Play, Square, Copy, CheckCircle2 } from 'lucide-react';
import { callVisionAPI, callTextAPI } from '../services/apiService';
import { getPromptByFuncId } from '../constants';

interface Props {
  tab: TabDefinition;
  isActive: boolean;
  settings: GlobalSettings;
  onZoomImage: (url: string) => void;
}

export const TabPanel: React.FC<Props> = ({ tab, isActive, settings, onZoomImage }) => {
  const [image1, setImage1] = useState<ImageFile | null>(null);
  const [image2, setImage2] = useState<ImageFile | null>(null);
  const [textInput, setTextInput] = useState('');
  const [generatedText, setGeneratedText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [statusText, setStatusText] = useState('生成内容');
  const [copyStatus, setCopyStatus] = useState(false);
  
  const abortControllerRef = useRef<AbortController | null>(null);

  // To handle image preview URLs memory leaks
  useEffect(() => {
    return () => {
      if (image1?.previewUrl) URL.revokeObjectURL(image1.previewUrl);
      if (image2?.previewUrl) URL.revokeObjectURL(image2.previewUrl);
    };
  }, []);

  const handleImageChange = (index: 1 | 2, file: File | null) => {
    const newImage = file ? { file, previewUrl: URL.createObjectURL(file) } : null;
    if (index === 1) {
        if (image1?.previewUrl) URL.revokeObjectURL(image1.previewUrl);
        setImage1(newImage);
    } else {
        if (image2?.previewUrl) URL.revokeObjectURL(image2.previewUrl);
        setImage2(newImage);
    }
  };

  const handleGenerate = async () => {
    const hasImage = image1 || image2;
    if (!hasImage && !textInput.trim()) {
        alert("请输入文本或上传图片。");
        return;
    }

    // Check API Keys
    if (hasImage && !settings[settings.provider].visionApiKey && settings.provider !== 'google') {
        alert('请先在设置中配置图片识别服务的 API Key。');
        return;
    }
    if (!settings[settings.provider].textApiKey && settings.provider !== 'google') {
        alert('请先在设置中配置文本生成服务的 API Key。');
        return;
    }
    // For Google, keys are still needed even if we simplify the check, let's rely on service to throw specific error or just simple check
    if (settings.provider === 'google' && !settings.google.visionApiKey && hasImage) {
       alert('请填写 Google API Key。');
       return;
    }

    setIsLoading(true);
    setGeneratedText('');
    abortControllerRef.current = new AbortController();

    try {
        let resultText = "";
        const visionPrompt = "请严格扮演一个高级OCR文字识别工具。你的任务是：识别我提供的图片中的所有文字，并智能地处理换行，最终输出通顺且格式正确的文本。\n\n【规则】：\n1.  仔细分析文本的上下文。如果一行文字在逻辑上是上一行句子的延续，请将它们合并成一个段落。\n2.  只有当遇到明显的段落分隔（例如缩进、较大的垂直间距）或者内容上开启了新的话题时，才进行换行。\n3.  最终只输出识别并格式化后的文字内容。\n4.  禁止添加任何说明、思考过程或额外内容。";
        
        if (hasImage) {
            setStatusText('步骤 1/2: 识别图片中...');
            const imagesToProcess = [];
            if (image1) imagesToProcess.push(image1);
            if (image2) imagesToProcess.push(image2);
            
            const imageDescription = await callVisionAPI(
                visionPrompt, 
                imagesToProcess, 
                settings, 
                abortControllerRef.current.signal
            );

            setStatusText('步骤 2/2: 生成病历中...');
            const finalPrompt = getPromptByFuncId(tab.id);
            const combinedText = `【用户输入的文本信息】:\n${textInput}\n\n【从图片中识别出的信息】:\n${imageDescription}`;
            
            resultText = await callTextAPI(
                finalPrompt, 
                combinedText, 
                settings, 
                abortControllerRef.current.signal
            );

        } else {
            setStatusText('生成中...');
            const prompt = getPromptByFuncId(tab.id);
            const fullTextPrompt = `【患者信息】:\n${textInput}`;
            resultText = await callTextAPI(
                prompt, 
                fullTextPrompt, 
                settings, 
                abortControllerRef.current.signal
            );
        }
        
        setGeneratedText(resultText || "AI未能生成内容。");
    } catch (error: any) {
        if (error.name === 'AbortError') {
            setGeneratedText('操作已由用户停止。');
        } else {
            setGeneratedText(`生成失败：${error.message}\n请检查 API 设置是否正确。`);
        }
    } finally {
        setIsLoading(false);
        setStatusText('生成内容');
        abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
        abortControllerRef.current.abort();
    }
  };

  const handleCopy = () => {
    if (!generatedText) return;
    navigator.clipboard.writeText(generatedText).then(() => {
        setCopyStatus(true);
        setTimeout(() => setCopyStatus(false), 2000);
    });
  };

  // Use CSS hidden instead of conditional rendering to preserve state when switching tabs
  return (
    <div className={`w-full animate-in fade-in slide-in-from-bottom-4 duration-500 ${isActive ? 'block' : 'hidden'}`}>
      <h2 className="text-xl font-bold text-gray-800 border-l-4 border-primary pl-3 mb-6 flex items-center">
        {tab.header}
      </h2>

      <div className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ImageUpload 
                label={tab.imageLabel1} 
                image={image1} 
                onChange={(f) => handleImageChange(1, f)} 
                onZoom={onZoomImage}
            />
            <ImageUpload 
                label={tab.imageLabel2} 
                image={image2} 
                onChange={(f) => handleImageChange(2, f)} 
                onZoom={onZoomImage}
            />
        </div>

        <textarea
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            placeholder={tab.textPlaceholder}
            className="w-full min-h-[120px] p-4 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all resize-y"
        />

        {/* Actions */}
        <div className="flex flex-col-reverse sm:flex-row justify-end gap-3 pt-4 border-t border-dashed border-gray-200">
            {isLoading && (
                <button 
                    onClick={handleStop}
                    className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-danger to-red-700 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all"
                >
                    <Square size={18} fill="currentColor" /> 停止
                </button>
            )}
            <button 
                onClick={handleGenerate}
                disabled={isLoading}
                className={`
                    flex items-center justify-center gap-2 px-8 py-3 text-white font-semibold rounded-lg shadow-lg transition-all
                    ${isLoading 
                        ? 'bg-gray-400 cursor-not-allowed' 
                        : 'bg-gradient-to-r from-accent to-emerald-600 hover:shadow-emerald-500/30 hover:-translate-y-0.5'
                    }
                `}
            >
                {isLoading ? (
                    <>
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin-custom" />
                        <span>{statusText}</span>
                    </>
                ) : (
                    <>
                        <Play size={20} fill="currentColor" /> <span>生成内容</span>
                    </>
                )}
            </button>
        </div>

        {/* Result */}
        {generatedText && (
            <div className="mt-8 border border-gray-200 rounded-xl overflow-hidden shadow-md bg-white animate-in fade-in slide-in-from-bottom-2">
                <div className="bg-gray-50 px-5 py-3 border-b border-gray-200 flex justify-between items-center">
                    <span className="font-bold text-gray-700 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-primary"></span> AI生成病历
                    </span>
                    <button 
                        onClick={handleCopy}
                        className={`
                            flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-md border transition-colors
                            ${copyStatus 
                                ? 'bg-green-50 text-green-600 border-green-200' 
                                : 'bg-white text-gray-600 border-gray-200 hover:text-primary hover:border-primary hover:bg-blue-50'
                            }
                        `}
                    >
                        {copyStatus ? <CheckCircle2 size={16} /> : <Copy size={16} />}
                        {copyStatus ? '已复制' : '复制内容'}
                    </button>
                </div>
                <pre className="p-6 whitespace-pre-wrap font-mono text-sm md:text-base text-gray-700 lined-paper min-h-[150px] max-h-[600px] overflow-y-auto custom-scrollbar">
                    {generatedText}
                </pre>
            </div>
        )}
      </div>
    </div>
  );
};