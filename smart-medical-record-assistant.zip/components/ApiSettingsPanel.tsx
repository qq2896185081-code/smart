import React, { useState } from 'react';
import { Settings, Save, Trash2, Zap, Check, X } from 'lucide-react';
import { GlobalSettings, ApiProvider } from '../types';

interface Props {
  isOpen: boolean;
  settings: GlobalSettings;
  onUpdateSettings: (newSettings: GlobalSettings) => void;
  onClose: () => void;
}

export const ApiSettingsPanel: React.FC<Props> = ({ isOpen, settings, onUpdateSettings, onClose }) => {
  const [quickConfig, setQuickConfig] = useState('');
  const [quickTarget, setQuickTarget] = useState<'vision' | 'text' | 'both'>('both');
  const [confirmDelete, setConfirmDelete] = useState<{key: string, label: string} | null>(null);

  const handleProviderChange = (provider: ApiProvider) => {
    onUpdateSettings({ ...settings, provider });
  };

  const updateField = (field: string, value: string) => {
    onUpdateSettings({
      ...settings,
      [settings.provider]: {
        ...settings[settings.provider],
        [field]: value
      }
    });
  };

  const handleDelete = (field: string) => {
    updateField(field, '');
    setConfirmDelete(null);
  };

  const parseQuickConfig = () => {
    const rawInput = quickConfig.trim();
    if (!rawInput) {
        alert("请先粘贴配置信息！");
        return;
    }

    let url = '';
    let key = '';
    let model = '';

    // Try JSON
    if (rawInput.startsWith('{')) {
        try {
            const json = JSON.parse(rawInput);
            url = json.url || json.baseUrl || json.host || json.endpoint || '';
            key = json.key || json.apiKey || json.token || '';
            model = json.model || json.modelName || '';
        } catch (e) {}
    }

    // Try Regex/Heuristic
    if (!url && !key && !model) {
        const parts = rawInput.split(/[\s,\|\n]+/).filter(p => p.trim() !== '');
        
        const urlIndex = parts.findIndex(p => p.startsWith('http://') || p.startsWith('https://'));
        if (urlIndex !== -1) {
            url = parts[urlIndex];
            parts.splice(urlIndex, 1);
        }
        
        const keyPrefixIndex = parts.findIndex(p => p.startsWith('sk-') || p.startsWith('AIza') || p.startsWith('sess-'));
        if (keyPrefixIndex !== -1) {
            key = parts[keyPrefixIndex];
            parts.splice(keyPrefixIndex, 1);
        }

        const modelHeuristicIndex = parts.findIndex(p => 
            p.includes('/') || 
            p.includes(':') || 
            /\d+\.\d+/.test(p) || 
            /^(gpt|claude|gemini|qwen|deepseek|llama|glm)/i.test(p)
        );
        if (!model && modelHeuristicIndex !== -1) {
            model = parts[modelHeuristicIndex];
            parts.splice(modelHeuristicIndex, 1);
        }

        if (!key && parts.length > 0) {
            const potentialKeyIndex = parts.findIndex(p => p.length > 20 && !p.includes('.') && !p.includes('/'));
             if (potentialKeyIndex !== -1) {
                key = parts[potentialKeyIndex];
                parts.splice(potentialKeyIndex, 1);
            }
        }
        if (!model && parts.length > 0) model = parts[0];
    }

    if (!url && !key && !model) {
        alert("未能识别出有效信息，请检查格式。");
        return;
    }

    const newSettings = { ...settings };
    const currentConfig = newSettings[settings.provider];

    if (quickTarget === 'vision' || quickTarget === 'both') {
        if(url) currentConfig.visionApiUrl = url;
        if(key) currentConfig.visionApiKey = key;
        if(model) currentConfig.visionModel = model;
    }
    if (quickTarget === 'text' || quickTarget === 'both') {
        if(url) currentConfig.textApiUrl = url;
        if(key) currentConfig.textApiKey = key;
        if(model) currentConfig.textModel = model;
    }

    onUpdateSettings(newSettings);
    setQuickConfig('');
    alert("快速配置已应用！");
  };

  const currentConfig = settings[settings.provider];
  const isGoogle = settings.provider === 'google';

  const renderField = (label: string, fieldKey: keyof typeof currentConfig, type: 'text' | 'password' = 'text', placeholder: string) => (
    <div className="mb-3">
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <div className="flex gap-2">
            <input 
                type={type}
                value={currentConfig[fieldKey]}
                onChange={(e) => updateField(fieldKey as string, e.target.value)}
                placeholder={placeholder}
                disabled={isGoogle && (fieldKey === 'visionApiUrl' || fieldKey === 'textApiUrl')}
                className="flex-1 p-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none disabled:bg-gray-100 disabled:text-gray-500"
            />
            {/* Simple save indicator is implied by state update, but let's keep the delete button */}
             <button 
                onClick={() => setConfirmDelete({key: fieldKey as string, label})}
                className="p-2 text-danger hover:bg-danger-light rounded-md transition-colors"
                title="删除"
             >
                 <Trash2 size={18} />
             </button>
        </div>
    </div>
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-x-0 top-[80px] md:top-[100px] z-40 pointer-events-none flex justify-center px-4">
      <div className="bg-white rounded-xl shadow-2xl border border-gray-200 w-full max-w-3xl pointer-events-auto overflow-hidden animate-in fade-in slide-in-from-top-4 duration-300">
        <div className="p-6 max-h-[80vh] overflow-y-auto custom-scrollbar">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                    <Settings className="text-primary" /> API 设置
                </h2>
                <button onClick={onClose} className="text-gray-500 hover:text-gray-800"><X /></button>
            </div>

            {/* Quick Config */}
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-6">
                <label className="text-primary font-semibold flex items-center gap-2 mb-2 text-sm">
                    <Zap size={16} /> 快速配置 (自动识别地址、Key、模型)
                </label>
                <textarea 
                    value={quickConfig}
                    onChange={e => setQuickConfig(e.target.value)}
                    className="w-full p-2 text-sm border border-blue-200 rounded-md mb-2 focus:outline-none focus:border-primary"
                    rows={3}
                    placeholder={`粘贴配置，支持换行。例如：\nhttps://api.xxx.com\nsk-xxxxxx\ngpt-4o`}
                />
                <div className="flex justify-end gap-2">
                     <select 
                        value={quickTarget}
                        onChange={(e) => setQuickTarget(e.target.value as any)}
                        className="text-sm border-gray-300 border rounded-md p-1 bg-white"
                     >
                        <option value="vision">仅图片服务</option>
                        <option value="text">仅文本服务</option>
                        <option value="both">全部服务</option>
                     </select>
                     <button 
                        onClick={parseQuickConfig}
                        className="bg-primary hover:bg-primary-hover text-white px-3 py-1 rounded-md text-sm flex items-center gap-1 transition-colors"
                     >
                        <Check size={14} /> 一键解析
                     </button>
                </div>
            </div>

            {/* Provider Select */}
            <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">API 提供商</label>
                <select 
                    value={settings.provider}
                    onChange={(e) => handleProviderChange(e.target.value as ApiProvider)}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                >
                    <option value="openai">OpenAI / 兼容格式 (DeepSeek, SiliconFlow, etc.)</option>
                    <option value="google">Google Gemini</option>
                </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h3 className="font-semibold text-gray-800 mb-3 pb-1 border-b border-gray-100">图片识别服务</h3>
                    {renderField("API 地址", "visionApiUrl", "text", isGoogle ? "自动生成" : "API Endpoint")}
                    {renderField("API Key", "visionApiKey", "password", "sk-...")}
                    {renderField("模型名称", "visionModel", "text", "e.g. gpt-4-vision")}
                </div>
                <div>
                    <h3 className="font-semibold text-gray-800 mb-3 pb-1 border-b border-gray-100">文本生成服务</h3>
                    {renderField("API 地址", "textApiUrl", "text", isGoogle ? "自动生成" : "API Endpoint")}
                    {renderField("API Key", "textApiKey", "password", "sk-...")}
                    {renderField("模型名称", "textModel", "text", "e.g. deepseek-chat")}
                </div>
            </div>
        </div>
      </div>

      {/* Confirm Delete Modal */}
      {confirmDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm pointer-events-auto">
              <div className="bg-white rounded-lg p-6 max-w-sm w-full shadow-xl transform scale-100">
                  <h3 className="text-lg font-bold text-gray-900 mb-2">确认删除</h3>
                  <p className="text-gray-600 mb-6">确定要清空 {confirmDelete.label} 吗？此操作不可撤销。</p>
                  <div className="flex justify-end gap-3">
                      <button onClick={() => setConfirmDelete(null)} className="px-4 py-2 text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">取消</button>
                      <button onClick={() => handleDelete(confirmDelete.key)} className="px-4 py-2 text-white bg-danger rounded-md hover:bg-danger-hover">确认删除</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};